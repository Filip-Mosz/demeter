package com.filipmoszczynski.demeter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemeterApplicationTests {

	@Test
	void contextLoads() {
	}

}
